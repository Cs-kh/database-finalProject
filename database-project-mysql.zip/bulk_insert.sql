INSERT INTO Customers (customer_name, email, phone_number) VALUES
('Smith', 'smith@example.com', '1234567890'),
('Bob', 'bob@example.com', '2345678901'),
('Alpha', 'alpha@example.com', '3456789012'),
('Raman', 'raman@example.com', '4567890123'),
('Evan', 'evan@example.com', '5678901234'),
('Fiona', 'fiona@example.com', '6789012345'),
('George', 'george@example.com', '7890123456'),
('Hannah', 'hannah@example.com', '8901234567'),
('Sara', 'sara@example.com', '9012345678'),
('Karim', 'karim@example.com', '0123456789');
INSERT INTO RestaurantTables (table_num, status,capacity) VALUES
(1, 'Available',2), (2,'Available', 2), (3, 'Reserved',4), (4, 'Available', 4), (5,'Available' ,6),
(6,  'Available',6), (7, 'Reserved',8), (8, 'Available', 2), (9, 'Available', 4), (10, 'Reserved',4);

INSERT INTO Staff (name, role, shift_time) VALUES
('Emily', 'Waiter', 'Morning'),
('John', 'Chef', 'Evening'),
('Linda', 'Manager', 'Morning'),
('Lya', 'Waiter', 'Evening'),
('Sara', 'Chef', 'Morning'),
('Lania', 'Waiter', 'Night'),
('Kate', 'Manager', 'Evening'),
('Mike', 'Waiter', 'Morning'),
('Nina', 'Host', 'Evening'),
('Ara', 'Chef', 'Night');

INSERT INTO Reservation (customer_id, table_num, reservation_time, gustes_num) VALUES
(1, 1, '2025-03-23 19:00:00', 2),
(2, 2, '2025-03-23 18:00:00', 2),
(3, 3, '2025-03-23 20:00:00', 4),
(4, 4, '2025-03-24 17:30:00', 4),
(5, 5, '2025-03-24 19:30:00', 6),
(6, 6, '2025-03-25 18:45:00', 6),
(7, 7, '2025-03-25 20:15:00', 8),
(8, 8, '2025-03-25 21:00:00', 2),
(9, 9, '2025-03-26 19:00:00', 4),
(10, 10, '2025-03-26 20:30:00', 4);

INSERT INTO Orders (customer_id, table_num, staff_id, total_amount) VALUES
(1, 1, 1,  45.00),
(2, 2, 2,  60.50),
(3, 3, 3,  32.00),
(4, 4, 4,  55.00),
(5, 5, 5,  72.00),
(6, 6, 6,  40.00),
(7, 7, 7, 88.00),
(8, 8, 8,  22.50),
(9, 9, 9,  64.00),
(10, 10, 10,  70.00);


INSERT INTO OrderItem (order_id,menu_id ,quantity, notes) VALUES
(1,2 , 2, 'No onions'),
(1, 3,1, 'nothing'),
(2, 1,3, 'Extra cheese'),
(3, 6, 2, 'Spicy'),
(4, 10 ,1, 'sweet'),
(5, 2,2, 'extra tomato'),
(6, 5 ,1, 'No salt'),
(7, 6 ,3, 'nothing'),
(8,  8,2, 'Add sauce'),
(9,  10,1, 'nothing');




