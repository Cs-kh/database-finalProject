CREATE SCHEMA restaurant_db;

USE restaurant_db;



set sql_safe_updates = 0;

Show variables like 'local_infile';
Set global local_infile = 1;