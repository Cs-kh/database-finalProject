CREATE TABLE Customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone_number VARCHAR(20)
);
CREATE TABLE RestaurantTables (
table_num INT  PRIMARY KEY,
status VARCHAR(20) DEFAULT 'Available',
capacity int 
);
CREATE TABLE Staff (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50),
    role VARCHAR(50),
    shift_time VARCHAR(50)
);
CREATE TABLE Reservation (
id INT AUTO_INCREMENT PRIMARY KEY ,
gustes_num int ,
reservation_time DATETIME,
    table_num int , 
    FOREIGN KEY (table_num ) REFERENCES RestaurantTables(table_num ),
   customer_id INT,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);

CREATE TABLE Orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    
    table_num int , 
    FOREIGN KEY (table_num ) REFERENCES RestaurantTables(table_num ),
     total_amount DECIMAL(10, 2),
     customer_id INT,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
     staff_id INT,
     FOREIGN KEY (staff_id) REFERENCES Staff(id)
);


CREATE TABLE OrderItem (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    menu_id INT, 
    quantity INT,
    notes VARCHAR(100),
    FOREIGN KEY (order_id) REFERENCES Orders(order_id)

);

