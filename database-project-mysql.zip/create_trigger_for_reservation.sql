DELIMITER //
CREATE TRIGGER update_table_after_reservation
AFTER INSERT ON Reservation
FOR EACH ROW
BEGIN
    UPDATE RestaurantTables
    SET status = 'Reserved'
    WHERE table_num = NEW.table_num;
END;
//
DELIMITER ;


DELIMITER //

CREATE TRIGGER set_table_available_after_delete
AFTER DELETE ON Reservation
FOR EACH ROW
BEGIN
    UPDATE RestaurantTables
    SET status = 'Available'
    WHERE table_num = OLD.table_num;
END;
//
DELIMITER ;

DROP TRIGGER restaurant_db.update_table_after_reservation