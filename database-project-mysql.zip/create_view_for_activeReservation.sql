-- in this view we have info about which table in the restaurant  resereved 

CREATE VIEW ActiveReservations AS
SELECT 
    r.id AS reservation_id,
     c.customer_name,
    r.reservation_time,
    r.gustes_num,
    rt.table_num,
    rt.status
FROM Reservation r
JOIN Customers c ON r.customer_id = c.customer_id
JOIN RestaurantTables rt ON r.table_num = rt.table_num
WHERE r.reservation_time >= NOW();

SELECT * FROM ActiveReservations;
