INSERT INTO Reservation (customer_id, table_num, reservation_time,  gustes_num)
VALUES (1, 2, '2025-03-23 19:00:00', 4);


SELECT * FROM RestaurantTables WHERE table_num = 2;

DELETE FROM Reservation WHERE id = 2;
