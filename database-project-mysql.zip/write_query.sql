-- 1. Get all customers
SELECT * FROM Customers;

-- 2. Find customers who have made a reservation
SELECT DISTINCT c.customer_name, c.email
FROM Customers c
JOIN Reservation r ON c.customer_id = r.customer_id;


-- 1. Find tables that can seat more than 4 guests
SELECT * FROM RestaurantTables WHERE capacity > 4;

-- 2. Find which tables were reserved on a specific date
SELECT rt.table_num, r.reservation_time
FROM RestaurantTables rt
JOIN Reservation r ON rt.table_num = r.table_num
WHERE DATE(r.reservation_time) = '2025-03-25';


-- 1. Find staff working the morning shift
SELECT * FROM Staff WHERE shift_time = 'Morning';

-- 2. Count how many staff work each shift
SELECT shift_time, COUNT(*) AS staff_count
FROM Staff
GROUP BY shift_time;

-- 1. View all upcoming reservations
SELECT r.id, c.customer_name AS customer, rt.table_num, r.reservation_time
FROM Reservation r
JOIN Customers c ON r.customer_id = c.customer_id
JOIN RestaurantTables rt ON r.table_num = rt.table_num
WHERE r.reservation_time > NOW()
ORDER BY r.reservation_time;



-- 1. Get all orders with customer and table details
SELECT o.order_id, c.customer_name AS customer, rt.table_num, o.total_amount
FROM Orders o
JOIN Customers c ON o.customer_id = c.customer_id
JOIN RestaurantTables rt ON o.table_num = rt.table_num;



-- 2. Orders handled by a specific staff member
SELECT o.order_id, o.total_amount
FROM Orders o
JOIN Staff s ON o.staff_id = s.id
WHERE s.name = 'Emily';

-- 1 . Most frequently used special notes
SELECT notes, COUNT(*) AS usage_count
FROM OrderItem
WHERE notes IS NOT NULL AND notes <> ''
GROUP BY notes
ORDER BY usage_count DESC;

